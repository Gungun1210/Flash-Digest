from sqlalchemy import Column, Integer, String, Text, TIMESTAMP
from sqlalchemy.sql import func
from db.database import Base  # Base is the SQLAlchemy base class

class Summary(Base):
    __tablename__ = "Summaries"  # Make sure this matches the exact name of your table in PostgreSQL

    id = Column(Integer, primary_key=True, index=True)  # Primary key
    source = Column(Text)  # Column for the source (e.g., 'YouTube' or 'BBC')
    content = Column(Text)  # Column for the full content
    summary = Column(Text)  # Column for the generated summary
    language = Column(String)  # Column for language, e.g., "English"
    sentiment = Column(String)  # Column for sentiment (e.g., "Neutral")
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())  # Timestamp for when the record is created

    def __repr__(self):
        return f"<Summary(id={self.id}, source={self.source}, language={self.language}, sentiment={self.sentiment})>"
